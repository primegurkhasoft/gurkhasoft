import React from 'react'

function CardsDetails() {
  return (
    <>CardsDetails</>
  )
}

export default CardsDetails